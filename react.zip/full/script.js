class App extends React.Component {
	// ------------
	constructor(){
			super();
			this.mes = 'Вкусный';
			this.state = {
				message: 'Вкусный',
			 	test: 'Не нажимать!',
				error:{name:false , date:true, check:false, type:true},
				yrob:[1,3,5,1,2,4,6,1,2]
			};
			this.aletr1 = this.aletr1.bind(this);
			this.aletr2 = this.aletr2.bind(this);
			this.delitArray = this.delitArray.bind(this);
			this.delit_1_Array = this.delit_1_Array.bind(this);
	 }
	  // ------------
		aletr1(){
			alert(this.mes);
			 this.setState({message: 'Не вкусно(('});
		}
		aletr2(){
				alert('Цифра ');
		}
		 // ------------
		 delitArray(){
			  this.setState ({yrob:[]});
		 }
		 delit_1_Array(){
			 let arr = this.state.yrob.slice(1);
			  this.setState ({yrob:arr});
		 }
	 	 // ------------
	render() {
			let yrob = this.state.yrob.map(function(elem, index){
				return <a key = {index}> {elem} </a>;
			});
			return( <div>
					<p onClick = {this.aletr1}>{yrob}</p>
					<div onClick = {this.delitArray}>КЛик что б удалить все цифры</div>
					<div onClick = {this.delit_1_Array}>КЛик что б удалить 1 цифры</div>
					</div>
		);
	
	// ------------
	}

	ReactDOM.render(
	<App />,
	document.getElementById('conteiner')
	);