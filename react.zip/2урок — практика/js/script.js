class App extends React.Component {
  // ------------
  constructor(){
     super();
     this.state = {
         inner: true,
         array: [1,1,2,3,5,12,3,8,3]
     };
     this.setFull = this.setFull.bind(this);
  }
  // ------------
  setFull(){
    if(this.state.inner === true){
      this.setState({inner: false});
    } else{
       this.setState({inner: true});
    }
  }
  getText(){
    if(this.state.inner === true){
           return <p>inner = true</p>;
    }else{
       return <p>inner = false</p>;
    }
  }
   // ------------
   getText1(){
       return 'text';
   }
    // ------------
render() {
 let get = this.getText();
 let get1 = this.getText1();
 let text;
 if(this.state.inner === true){
   text = <div>Макс</div>;
 }else{
     text = <div>Смог</div>;
 }
   // ------------
 const array = this.state.array.map(function(elem, index) {
    return <li key={index}>{+elem}</li>;
 });

  // ------------
     return(
       <div className = 'full'>
       <ul className = "array"> {array} </ul>
         {text}
         {get}
         <button onClick = {this.setFull}>Изменить состояние</button>
         <p> {get1} </p>
       </div>
   );
}
// ------------
}
ReactDOM.render(
   <App />,
     document.getElementById('conteiner')
 ); 
